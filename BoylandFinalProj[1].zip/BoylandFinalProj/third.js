function changeImage(x,image){

    if(x===1){
    
        image.src='desktop.jpg';
    }
    if(x===2){
    
        image.src = 'over.jpg';
    }
    
    }