"use strict";
const $ = selector => document.querySelector(selector);

/*********************
*  helper functions  *
whenever user presses either fahrenheit or Celcius, DOM LBLs switches
**********************/
function calculateCelsius(temp){
	return Math.floor((temp-32) * 5/9);

} 

function calculateFahrenheit(temp)  {

	return Math.floor(temp * 9/5 + 32);

} 

function toggleDisplay (label1Text, label2Text)  {
//whenever user clicks one of the radio buttons change (label)

   //code for label1text
 // label1Text = document.querySelectorAll("input[name='conversion_type']:checked");// all radioButton
  c2f =  document.getElementById("to_celsius");
  f2c = label2Text.document.getElementById("to_fahrenheit");

  label1Text.forEach(radioBtn => {

	if(radioBtn === c2f.checked){
    label1Text = c2f;
    
	}
	else if(radioBtn === f2c.checked){
        label1Text = f2c;

	}
  });

//lable2text
/** 
 * 
 * When label1text is clicked => to_celsius
 * label2text is clicked => change to celsius to btn2. 
 * radiobutton c2f == Enter C degrees 
 * radiobutton f2c == Enter F degrees
*/

//code for changing radio labels 

//code for changing data labels

};


/****************************
*  event handler functions  *
*****************************/
//function convertTemp()  {   
	
//};


//function toFahrenheit(){

	

//} 

document.addEventListener("DOMContentLoaded",  function(){ 
	var one = document.getElementById("to_celsius");
    var two = document.getElementById("to_fahrenheit");
    var button = document.getElementById("convert");
	// add event handlers .focus for event listner to work
	//event handlers when user clicks on any of the buttons alltemp = parseFloat(querySelector("degrees_entered"));
   //button.addEventListener("click", convertTemp()).focus();//button not working within the id computed degrees
   //one.addEventListener("click", toCelsius()).focus();//click to change display
   //two.addEventListener("click", toFahrenheit()).focus();//need to add code to toggleDisplay for everything to work 
	button.onclick = function convertTemp(){

		let conversionType = parseFloat(document.querySelector("input[name='conversion_type']"));//based off what is checked in radio button
		let alltemp = parseFloat(document.querySelector("#degrees_entered"));//degrees entered 
		let La = parseFloat(document.getElementById("lbl1"));//degrees entered label
		let La2 = parseFloat(document.getElementById("lbl2"));//degrees calcualted label 
		let resultText = document.getElementById("degrees_computed");
		
		//resultText =  parseFloat(document.getElementById("degrees_computed"));
		const errorDisplay = document.getElementById('error');

		if (isNaN(alltemp)) {
			errorDisplay.textContent = 'Please enter a valid number for degrees.';
			resultText = '';
		  } else {
			errorDisplay.textContent = '';
		  }

		  if (conversionType.checked == La) {//when conversionType is equal to document.getELbyid to_celcius 
                
			//alltemp = parseFloat(document.getElementById("degrees_entered"));
			resultText.textContent = calculateCelsius(alltemp);
		  }
		  else if(conversionType.checked == La2){

            resultText.textContent = calculateFahrenheit(alltemp);
        
		  }
	};
	one.change = function toCelsius(){
		

			toggleDisplay("Enter F degrees:", "Degrees Celsius:");
		
	};
	two.change = function toFahrenheit(){

		toggleDisplay("Enter C degrees:", "Degrees Fahrenheit:");

	};
	
	
	// move focus
	//$("#degrees_entered").focus();
});
